using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace SV
{

    public class Button_LevelUp : Button
    {
        public PlayerSkill _ps;
        public Category _cat;
    }
}
